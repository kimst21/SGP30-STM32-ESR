/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body with SGP30 + OLED display
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include "i2c.h"            // I2C3 사용 (OLED 및 SGP30 통신)
#include "usb_device.h"     // USB CDC 통신용 초기화
#include "gpio.h"           // GPIO 초기화 (필요 시 LED 등 제어)

/* USER CODE BEGIN Includes */
#include "sensirion_common.h" // SGP30 공통 라이브러리
#include "sgp30.h"            // SGP30 센서 제어 함수 포함
#include "usbd_cdc_if.h"      // USB CDC 전송 함수
#include <stdio.h>             // printf(), sprintf() 사용
#include <string.h>            // 문자열 처리 함수 사용
#include "ssd1306.h"          // SSD1306 OLED 드라이버
#include "fonts.h"            // 폰트 정의 (Font_7x10 등)
/* USER CODE END Includes */

/* USER CODE BEGIN PV */
char cdcBuf[64];              // USB CDC 출력용 버퍼
char oledBuf[64];             // OLED 출력용 버퍼
uint32_t measurement_counter = 0; // 측정 횟수 저장용 변수
/* USER CODE END PV */

void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
// printf()를 USB CDC로 전송되도록 재정의하는 함수
int _write(int file, char *ptr, int len) {
    CDC_Transmit_FS((uint8_t*) ptr, len);  // CDC로 문자열 전송
    return len;  // 전송된 길이 반환
}
/* USER CODE END PFP */

int main(void)
{
  // HAL 라이브러리 및 시스템 초기화
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();         // GPIO 초기화
  MX_I2C3_Init();         // I2C3 초기화 (SGP30, OLED)
  MX_USB_DEVICE_Init();   // USB CDC 초기화

  /* USER CODE BEGIN Init */
  SSD1306_Init();         // OLED 초기화
  SSD1306_Clear();        // OLED 화면 지우기
  SSD1306_UpdateScreen(); // 지운 내용 적용

  // USB CDC로 시작 메시지 전송
  printf("\r\nSGP30 Air Quality Sensor Starting...\r\n");

  // SGP30 센서가 연결되었는지 확인
  while (sgp_probe() != STATUS_OK) {
    printf("SGP sensor probing failed ... check I2C connection\r\n");
    SSD1306_GotoXY(0, 0);
    SSD1306_Puts("SGP30 not found", &Font_7x10, 1);  // OLED에 에러 메시지 표시
    SSD1306_UpdateScreen();
    HAL_Delay(1000);  // 1초 대기 후 재시도
  }

  printf("SGP sensor probing successful\r\n");
  SSD1306_GotoXY(0, 0);
  SSD1306_Puts("SGP30 found", &Font_7x10, 1);  // OLED에 성공 메시지 표시
  SSD1306_UpdateScreen();
  HAL_Delay(1000);

  // 측정에 사용할 변수 선언
  s16 err;
  u16 tvoc_ppb, co2_eq_ppm;
  u32 iaq_baseline;

  // IAQ 측정 초기화
  err = sgp_iaq_init();
  if (err != STATUS_OK) {
    printf("IAQ init failed\r\n");  // 실패 시 메시지 출력
  }
  /* USER CODE END Init */

  // 메인 루프 시작
  while (1)
  {
    // SGP30 측정값 읽기
    err = sgp_measure_iaq_blocking_read(&tvoc_ppb, &co2_eq_ppm);
    if (err == STATUS_OK) {
      measurement_counter++;  // 측정 횟수 증가

      // USB CDC로 측정값 출력
      printf("tVOC : %5d ppb  CO2eq : %5d ppm  Count: %lu\r\n", tvoc_ppb, co2_eq_ppm, measurement_counter);

      // OLED에 측정값 출력
      SSD1306_Clear();  // 이전 내용 삭제

      sprintf(oledBuf, "tVOC : %5d ppb", tvoc_ppb);   // tVOC 값 문자열 구성
      SSD1306_GotoXY(0, 0);
      SSD1306_Puts(oledBuf, &Font_7x10, 1);           // OLED에 출력

      sprintf(oledBuf, "CO2eq: %5d ppm", co2_eq_ppm); // CO2eq 값 문자열 구성
      SSD1306_GotoXY(0, 12);
      SSD1306_Puts(oledBuf, &Font_7x10, 1);

      sprintf(oledBuf, "Count: %lu", measurement_counter); // 측정 횟수
      SSD1306_GotoXY(0, 24);
      SSD1306_Puts(oledBuf, &Font_7x10, 1);

      SSD1306_UpdateScreen();  // OLED에 적용
    } else {
      printf("Error reading IAQ\r\n");  // 측정 실패 시 메시지 출력
    }

    // 1분(60회)마다 IAQ 베이스라인 출력
    if (measurement_counter % 60 == 0) {
      err = sgp_get_iaq_baseline(&iaq_baseline);
      if (err == STATUS_OK) {
        printf("Baseline: %lu\r\n", iaq_baseline);  // 베이스라인 출력
      }
    }

    HAL_Delay(1000); // 1초 대기 후 다음 측정
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
