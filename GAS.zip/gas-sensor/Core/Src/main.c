/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"        // 기본 HAL 라이브러리 및 주변 장치 정의
#include "i2c.h"         // I2C 초기화 및 제어 헤더
#include "usb_device.h"  // USB CDC 초기화 및 설정 헤더
#include "gpio.h"        // GPIO 핀 제어 헤더

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "sensirion_common.h" // SGP30 공통 라이브러리
#include "sgp30.h"            // SGP30 센서 드라이버
#include "usbd_cdc_if.h"      // USB CDC 데이터 송신 인터페이스
#include <stdio.h>            // printf 함수 사용을 위한 표준 라이브러리
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
char cdcBuf[30]; // USB CDC 데이터 전송용 버퍼
uint16_t count = 0; // 측정 데이터 카운트 추적
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/**
 * @brief printf 출력 데이터를 USB CDC로 송신하는 함수.
 *
 * @param file 파일 디스크립터 (사용하지 않음)
 * @param ptr 데이터 버퍼 포인터
 * @param len 데이터 길이
 * @return 전송된 데이터 길이
 */
int _write(int file, char *ptr, int len) {
    CDC_Transmit_FS((uint8_t*) ptr, len); // USB CDC를 통해 데이터 전송
    return len; // 전송된 데이터 길이 반환
}
/* USER CODE END PFP */

/* Main application entry point -----------------------------------------------*/
int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/

  /* HAL 라이브러리 및 주변 장치 초기화 */
  HAL_Init(); // HAL 라이브러리 초기화 (타이머, 인터럽트 등 설정)

  /* 시스템 클럭 설정 */
  SystemClock_Config(); // PLL 및 클럭 분주기 설정

  /* GPIO, I2C, USB 장치 초기화 */
  MX_GPIO_Init();
  MX_I2C3_Init();
  MX_USB_DEVICE_Init();

  /* 무한 루프 시작 */
  while (1)
  {
    /* 변수 선언 */
    u16 i = 0;                    // 루프 반복 카운터
    s16 err;                      // 에러 상태 저장 변수
    u16 tvoc_ppb, co2_eq_ppm;     // TVOC와 CO2eq 데이터 저장
    u32 iaq_baseline;             // IAQ 베이스라인 값
    u16 scaled_ethanol_signal, scaled_h2_signal; // 에탄올 및 수소 신호 값
    u32 measurement_counter = 0;  // 데이터 측정 횟수

    /* 초기 메시지 출력 */
    printf("\r\n");
    printf("SGP30 Air Quality Sensor Demonstration\r\n");

    /* SGP30 센서 연결 확인 */
    while (sgp_probe() != STATUS_OK) {
      printf("SGP sensor probing failed ... check SGP30 I2C connection\r\n");
      HAL_Delay(500); // 재시도 대기
    }
    printf("SGP sensor probing successful\r\n");

    /* 초기 신호 측정 */
    err = sgp_measure_signals_blocking_read(&scaled_ethanol_signal, &scaled_h2_signal);
    if (err == STATUS_OK) {
      printf("Ethanol signal: %f \r\n", scaled_ethanol_signal / 512.0f);
      printf("H2 signal: %f \r\n", scaled_h2_signal / 512.0f);
    } else {
      printf("Error reading Ethanol and H2 signals\r\n");
    }

    /* IAQ 초기화 */
    err = sgp_iaq_init();
    if (err != STATUS_OK) {
      printf("Error initializing IAQ\r\n");
    }

    /* 데이터 측정 루프 */
    while (1)
    {
      /* IAQ 측정 데이터 읽기 */
      err = sgp_measure_iaq_blocking_read(&tvoc_ppb, &co2_eq_ppm);
      if (err == STATUS_OK) {
        measurement_counter++;
        printf("tVOC : %5d [ppb]     CO2eq : %5d [ppm]     Measurement #: %10lu\r\n", tvoc_ppb, co2_eq_ppm, measurement_counter);
      } else {
        printf("Error reading IAQ values\r\n");
      }

      /* LED 상태 제어 */
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET); // LED ON

      /* 1분마다 IAQ 베이스라인 출력 */
      if (measurement_counter % 60 == 0) {
        err = sgp_get_iaq_baseline(&iaq_baseline);
        if (err == STATUS_OK) {
          printf("Current baseline values: %5lu\r\n", iaq_baseline);
        }
      }

      /* 1시간마다 베이스라인 저장 */
      if (++i % 60 == 1) {
        err = sgp_get_iaq_baseline(&iaq_baseline);
        if (err == STATUS_OK) {
          printf("Baseline saved for next startup: %5lu\r\n", iaq_baseline);
        }
      }

      /* LED 상태 해제 및 1초 대기 */
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET); // LED OFF
      HAL_Delay(1000); // 1초 대기
    }
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
